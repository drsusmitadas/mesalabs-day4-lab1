import glob
from rotation import read_model, read_summary, read_detail, compute_splitting

model = read_model('profile1.data.GYRE')
detail_files = glob.glob('lab3_details/detail.l1.n*.txt')

print(f"{'n':>5}  {'β (1-C)':>10}  {'δω (μHz)':>10}")
print("-" * 30)

for detail_file in detail_files:
    try:
        ρ, r, Ω, ξr, ξh, l = read_detail(model, detail_file)
        β, δω = compute_splitting(Ω, ρ, r, ξr, ξh, l)

        # extract radial order n from the file
        n_str = detail_file.split('n')[-1].split('.')[0]
        n = int(n_str)

        print(f"{n:>5}  {β:10.4f}  {δω*1e6:10.4f}")  # 转成 μHz
    except Exception as e:
        print(f"Failed on {detail_file}: {e}")
