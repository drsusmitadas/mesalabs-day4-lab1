# Rotation and centrifugal-force kernels, K_rot(r) and K_cent(r).
# These are to be integrated with respect to r, multiplied against
# 4πr²ρ and the rotational profile Ω(r), to yield the rotational
# splitting δω, under the normalisation convention that
# \int (ξr² + l(l+1) ξh²)4πr²ρ dr = 1.
# Integrating K_rot against a unit rotational profile gives
# the solid-body rotational sensitivity constant mβ = m(1-C).
# C ~ 1 for a p-mode and ~ 1/l(l+1) for a g-mode.

import numpy as np
import pygyre
from scipy.integrate import trapezoid

def rot_kernel(ξr1, ξh1, ξr2, ξh2, l, m):
    Λ2 = l * (l + 1)
    return 2*m * (ξr1.conj() * ξr2 + (Λ2 - 1) * (ξh1.conj() * ξh2) - ξr1.conj() * ξh2 - ξh1.conj() * ξr2)

def inertia(ρ, r, ξr, ξh, l):
    Λ2 = l * (l + 1)
    return trapezoid(ρ * r**2 * (np.abs(ξr)**2 + Λ2 * np.abs(ξh)**2), r)

def read_model(model_file):
    return pygyre.read_model(model_file)

def read_summary(summary_file):
    return pygyre.read_output(summary_file)

def read_detail(model, detail_file):
    """Read detail from one mode file."""
    R = model.meta['R_star']  # in CGS units
    detail = pygyre.read_output(detail_file)

    ξr = detail['xi_r']
    ξh = detail['xi_h']
    ρ = detail['rho']
    r = detail['x'] * R
    #l = int(detail.meta['l'])  # l is needed in compute_splitting()
    l = 1

    Ω = np.interp(r, model['r'], model['Omega_rot'])
    return ρ, r, Ω, ξr, ξh, l

def compute_splitting(Ω, ρ, r, ξr, ξh, l):
    K = ρ * r**2 * rot_kernel(ξr, ξh, ξr, ξh, l, 1)  # fixed variable names
    I = inertia(ρ, r, ξr, ξh, l)
    β = trapezoid(K, r) / I / 2
    δω = trapezoid(Ω * K, r) / I / 2
    return β, δω
